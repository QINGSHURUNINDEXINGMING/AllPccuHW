﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyMVCHW004WebAPIs.Models
{
	public class SportType
	{
		// 定義消費種類資料表紀錄之欄位名稱與資料型態
		public int id { get; set; }

		public string sportType { get; set; }
	}
}